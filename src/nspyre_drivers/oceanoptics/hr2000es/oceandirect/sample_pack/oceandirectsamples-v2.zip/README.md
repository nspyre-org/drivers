Sample code for OceanDirect in a selection of common languages.
